## Module <om_credit_limit>

#### 15.04.2022
#### Version 15.0.2.1.0
##### IMP
- turkish translation
