##Turkish - Alaattin Kahramanlar
